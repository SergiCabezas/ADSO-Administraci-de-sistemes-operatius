#!/bin/bash

# Variables
USER_HOME="/home/sergiS"
BACKUP_DIR="$USER_HOME/backups"
DATE=$(date '+%Y-%m-%d')
BACKUP_NAME="backup_total_$DATE.tar.gz"

# Crear el directori de backups si no existeix
mkdir -p "$BACKUP_DIR"

# Fer el backup complet (excloent el directori de backups)
tar --exclude="$BACKUP_DIR" -czf "$BACKUP_DIR/$BACKUP_NAME" "$USER_HOME"

echo "Backup complet realitzat: $BACKUP_NAME"

