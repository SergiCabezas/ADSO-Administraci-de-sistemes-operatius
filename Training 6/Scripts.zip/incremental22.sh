#!/bin/bash

# Variables
REMOTE_USER="aso"
REMOTE_HOST="172.16.1.2"
REMOTE_BACKUP_DIR="/home/aso/backups"
SOURCE_DIR="/var/log"
EXCLUDE="*.gz"
TIMESTAMP=$(date +"%Y%m%d%H%M")
BACKUP_NAME="backup-log-nivell2-${TIMESTAMP}"
LOCAL_BACKUP_DIR="/tmp/${BACKUP_NAME}"

# Rsync incremental
rsync -av --exclude="${EXCLUDE}" \
    --chmod=ug=rwX,o= \
    "${SOURCE_DIR}/" "${LOCAL_BACKUP_DIR}"

# Copiar al servidor remoto
rsync -av "${LOCAL_BACKUP_DIR}" "${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_BACKUP_DIR}/"

# Rotación: mantener la última copia de nivel 2
ssh ${REMOTE_USER}@${REMOTE_HOST} "cd ${REMOTE_BACKUP_DIR} && ls -t | grep 'backup-log-nivell2' | tail -n +2 | xargs -I {} rm -rf {}"

