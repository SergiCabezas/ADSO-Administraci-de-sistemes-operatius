#!/bin/bash

DIRECTORI_ORIGEN="/var/log"
EXCLUSIONS="*.gz"
DESTI="172.16.1.2:/home/aso/backups"
NIVELL="nivell0"
DATA=$(date +"%Y%m%d%H%M%S")
NOM_COPIA="backup-log-${NIVELL}-${DATA}"
DIRECTORI_DESTI="$DESTI/$NOM_COPIA"

# Comprovar connexió SSH
if ! ssh -q 172.16.1.2 exit; then
  echo "Error: No es pot establir connexió SSH amb la màquina remota."
  exit 1
fi

# Esborrar còpia de seguretat anterior de nivell 0
ssh 172.16.1.2 "cd /home/aso/backups && rm -rf backup-log-${NIVELL}-*"
DELETE_RESULT=$?

if [ $DELETE_RESULT -eq 0 ]; then
  echo "Còpia de seguretat anterior esborrada amb èxit."
else
  echo "Error: No s'ha pogut esborrar la còpia de seguretat anterior."
  exit 2
fi

# Crear nova còpia de seguretat
rsync -av --exclude="$EXCLUSIONS" --chmod=u=rwx,g=,o= "$DIRECTORI_ORIGEN/" "$DIRECTORI_DESTI"
RSYNC_RESULT=$?

if [ $RSYNC_RESULT -eq 0 ]; then
  echo "Còpia de seguretat de nivell 0 completada amb èxit."
else
  echo "Error: No s'ha pogut realitzar la còpia de seguretat."
  exit 3
fi

