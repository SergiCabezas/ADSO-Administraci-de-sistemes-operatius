#!/bin/bash

# Variables
USER_HOME="/home/sergiS"
BACKUP_DIR="$USER_HOME/backups"
MAX_SIZE_MB=100

# Calcular l'espai ocupat pels backups
CURRENT_SIZE_MB=$(du -sm "$BACKUP_DIR" | cut -f1)

# Comprovar si supera el límit
if [ "$CURRENT_SIZE_MB" -gt "$MAX_SIZE_MB" ]; then
    echo "Espai actual: ${CURRENT_SIZE_MB}MB. Eliminant backups antics fins reduir a ${MAX_SIZE_MB}MB..."

    # Ordenar els fitxers per data de modificació i eliminar fins complir el límit
    for BACKUP_FILE in $(ls -t "$BACKUP_DIR"); do
        rm "$BACKUP_DIR/$BACKUP_FILE"
        CURRENT_SIZE_MB=$(du -sm "$BACKUP_DIR" | cut -f1)
        
        if [ "$CURRENT_SIZE_MB" -le "$MAX_SIZE_MB" ]; then
            break
        fi
    done

    echo "Neteges completes. Espai actual: $(du -sm "$BACKUP_DIR" | cut -f1)MB."
else
    echo "Espai actual: ${CURRENT_SIZE_MB}MB. No cal eliminar res."
fi

