#!/bin/bash

# Variables
USER_HOME="/home/sergiS"
BACKUP_DIR="$USER_HOME/backups"
DATE=$(date '+%Y-%m-%d')
BACKUP_NAME="backup_incremental_$DATE.tar.gz"
SNAPSHOT_FILE="$BACKUP_DIR/snapshot.file"

# Crear el directori de backups si no existeix
mkdir -p "$BACKUP_DIR"

# Fer el backup incremental (excloent el directori de backups)
tar --exclude="$BACKUP_DIR" --listed-incremental="$SNAPSHOT_FILE" -czf "$BACKUP_DIR/$BACKUP_NAME" "$USER_HOME"

echo "Backup incremental realitzat: $BACKUP_NAME"

