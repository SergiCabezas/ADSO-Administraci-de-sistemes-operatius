SOURCE_DIR="/var/log"
EXCLUDE="*.gz"
TIMESTAMP=$(date +"%Y%m%d%H%M")
BACKUP_NAME="backup-log-nivell1-${TIMESTAMP}"
LOCAL_BACKUP_DIR="/tmp/${BACKUP_NAME}"
BACKUP_STORAGE_DIR="/tmp/backups"

# Crear directorio de almacenamiento de backups si no existe
mkdir -p "${BACKUP_STORAGE_DIR}"

# Rsync incremental
rsync -av --exclude="${EXCLUDE}" \
    --chmod=ug=rwX,o= \
    "${SOURCE_DIR}/" "${LOCAL_BACKUP_DIR}"

# Mover el backup al directorio de almacenamiento
mv "${LOCAL_BACKUP_DIR}" "${BACKUP_STORAGE_DIR}/"

# Rotación: mantener las 3 últimas copias de nivel 1
cd "${BACKUP_STORAGE_DIR}" && ls -t | grep 'backup-log-nivell1' | tail -n +4 | xargs -I {} rm -rf {}

